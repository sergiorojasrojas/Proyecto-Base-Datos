-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 19-10-2020 a las 10:59:20
-- Versión del servidor: 10.4.13-MariaDB
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_online`
--

-- --------------------------------------------------------

--
-- Estructura para la vista `clientes_grancanaria`
--

DROP VIEW IF EXISTS `clientes_grancanaria`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clientes_grancanaria`  AS  select `cliente`.`Código_Cliente` AS `Código_Cliente`,`cliente`.`Id_Comercial` AS `Id_Comercial`,`cliente`.`Nombre_Completo` AS `Nombre_Completo`,`cliente`.`Teléfono` AS `Teléfono`,`cliente`.`Email` AS `Email`,`cliente`.`Municipio` AS `Municipio`,`cliente`.`Dirección` AS `Dirección`,`cliente`.`CódigoPostal` AS `CódigoPostal`,`cliente`.`Provincia` AS `Provincia`,`cliente`.`Fecha_Nacimiento` AS `Fecha_Nacimiento` from `cliente` where `cliente`.`Provincia` like 'Gran Canaria' order by `cliente`.`Nombre_Completo` ;

--
-- VIEW `clientes_grancanaria`
-- Datos: Ninguna
--

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
