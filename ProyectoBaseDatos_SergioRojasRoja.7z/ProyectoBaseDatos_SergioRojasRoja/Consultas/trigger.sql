-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 21-10-2020 a las 06:17:03
-- Versión del servidor: 10.4.13-MariaDB
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_online`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `Código_Cliente` int(11) NOT NULL,
  `Id_Comercial` int(11) NOT NULL,
  `Nombre_Completo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Teléfono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `Email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Municipio` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Dirección` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `CódigoPostal` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Provincia` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Fecha_Nacimiento` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`Código_Cliente`),
  KEY `Id_Comercial` (`Id_Comercial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Código_Cliente`, `Id_Comercial`, `Nombre_Completo`, `Teléfono`, `Email`, `Municipio`, `Dirección`, `CódigoPostal`, `Provincia`, `Fecha_Nacimiento`) VALUES
(1, 1, 'Luis Pérez Pérez', '654789751', 'luis@gmail.com', 'La Laguna', 'Las Canteras', '38293', 'S/C de Tenerife', '18/04/1980'),
(2, 15, 'PacoGarcía García', '654789000', 'paco@gmail.com', 'Adeje', 'Las Rosas ', '38296', 'S/C de Tenerife', '16/06/1988'),
(3, 2, 'Lorena García Rojas', '651230478', 'lorena@gmail.com', 'El Rosario', 'El Parral nº 4', '38210', 'S/C de Tenerife', '10/03/2000'),
(4, 3, 'Esperanza Gracia Pérez', '654786321', 'esperanza@gmail.com', 'Arucas', 'El charco nº 7', '38964', 'Gran Canaria', '10/01/2000'),
(5, 2, 'Sergio García Pérez', '654789222', 'sergio@gmail.com', 'Arona', 'El Ramonal nº 1', '38210', 'S/C de Tenerife', '10/03/1990'),
(6, 7, 'Pedro Rojas Rojas', '654741000', 'pedro@gmail.com', 'El Paso', ' El Cedro nº 6', '38100', 'S/C de Tenerife', '02/06/2001'),
(7, 12, 'César Laampedro Rojas', '654122021', 'cesar@gmail.com', 'S/C de Tenerife', 'El cabo nº 4', '38200', 'S/C de Tenerife', '10/02/1988'),
(8, 8, 'Elías Bacallado Bacallado', '654879100', 'elias@gmail.com', 'La Laguna', 'Camino Las Mercedes', '38293', 'S/C de Tenerife', '06/01/1992'),
(9, 11, 'Marta Rojas Rojas', '612879123', 'marta@gmail.com', 'Agaete', 'El Barco nº 6', '38123', 'Gran Canaria', '02/06/1995'),
(10, 8, 'Luis Del Olmo Rojas', '654789200', 'olmo@gmail.com', 'Tegueste', 'Calle Los Pobres 11', '38294', 'S/C de Tenerife', '12/05/1982'),
(11, 4, 'Francisca Rojas Pérez', '654789111', 'francisca@gmail.com', 'Candelaria', 'El Volcán nº 2', '38295', 'S/C de Tenerife', '11/04/1996'),
(12, 9, 'Peter Jam Jim', '651423000', 'peter@gmail.com', 'Guía de Isora', 'El Hostal nº 3', '38963', 'S/C de Tenerife', '11/01/1980'),
(13, 6, 'Oleger ´Díaz Alonso', '625456123', 'oleger@gmail.com', 'Teror', 'El Fresón nº 1', '38269', 'Gran Canaria', '12/06/1976'),
(14, 11, 'Rosa María Pérez Rojas', '654963369', 'rosa@gmail.com', 'La Laguna', 'La Laja nº 7', '38293', 'S/C de Tenerife', '12/04/1998'),
(15, 13, 'Elías Santana Santana', '654789320', 'eliassantana@gmail.com', 'Telde', 'El Mesén nº 8', '38295', 'Gran Canaria', '12/03/1992');

--
-- Disparadores `cliente`
--
DROP TRIGGER IF EXISTS `trigger_cliente_historico`;
DELIMITER $$
CREATE TRIGGER `trigger_cliente_historico` AFTER INSERT ON `cliente` FOR EACH ROW BEGIN 
 INSERT INTO cliente_historico(Código_Cliente, Id_Comercial, Nombre_Completo,Teléfono,Email,Municipio,Dirección,CódigoPostal,Provincia,Fecha_Nacimiento)
   VALUES (NEW.Código_Cliente, NEW.Id_Comercial, NEW.Nombre_Completo,NEW.Teléfono,NEW.Email,NEW.Municipio,NEW.Dirección,NEW.CódigoPostal,NEW.Provincia,NEW.Fecha_Nacimiento);
END
$$
DELIMITER ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`Id_Comercial`) REFERENCES `comercial_soporte` (`Id_Comercial`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
