-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 21-10-2020 a las 16:25:39
-- Versión del servidor: 10.4.13-MariaDB
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_online`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `Código_Cliente` int(11) NOT NULL,
  `Id_Comercial` int(11) NOT NULL,
  `Nombre_Completo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Teléfono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `Email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Municipio` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Dirección` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `CódigoPostal` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Provincia` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Fecha_Nacimiento` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`Código_Cliente`),
  KEY `Id_Comercial` (`Id_Comercial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Código_Cliente`, `Id_Comercial`, `Nombre_Completo`, `Teléfono`, `Email`, `Municipio`, `Dirección`, `CódigoPostal`, `Provincia`, `Fecha_Nacimiento`) VALUES
(1, 1, 'Luis Pérez Pérez', '654789751', 'luis@gmail.com', 'La Laguna', 'Las Canteras', '38293', 'S/C de Tenerife', '18/04/1980'),
(2, 15, 'PacoGarcía García', '654789000', 'paco@gmail.com', 'Adeje', 'Las Rosas ', '38296', 'S/C de Tenerife', '16/06/1988'),
(3, 2, 'Lorena García Rojas', '651230478', 'lorena@gmail.com', 'El Rosario', 'El Parral nº 4', '38210', 'S/C de Tenerife', '10/03/2000'),
(4, 3, 'Esperanza Gracia Pérez', '654786321', 'esperanza@gmail.com', 'Arucas', 'El charco nº 7', '38964', 'Gran Canaria', '10/01/2000'),
(5, 2, 'Sergio García Pérez', '654789222', 'sergio@gmail.com', 'Arona', 'El Ramonal nº 1', '38210', 'S/C de Tenerife', '10/03/1990'),
(6, 7, 'Pedro Rojas Rojas', '654741000', 'pedro@gmail.com', 'El Paso', ' El Cedro nº 6', '38100', 'S/C de Tenerife', '02/06/2001'),
(7, 12, 'César Laampedro Rojas', '654122021', 'cesar@gmail.com', 'S/C de Tenerife', 'El cabo nº 4', '38200', 'S/C de Tenerife', '10/02/1988'),
(8, 8, 'Elías Bacallado Bacallado', '654879100', 'elias@gmail.com', 'La Laguna', 'Camino Las Mercedes', '38293', 'S/C de Tenerife', '06/01/1992'),
(9, 11, 'Marta Rojas Rojas', '612879123', 'marta@gmail.com', 'Agaete', 'El Barco nº 6', '38123', 'Gran Canaria', '02/06/1995'),
(10, 8, 'Luis Del Olmo Rojas', '654789200', 'olmo@gmail.com', 'Tegueste', 'Calle Los Pobres 11', '38294', 'S/C de Tenerife', '12/05/1982'),
(11, 4, 'Francisca Rojas Pérez', '654789111', 'francisca@gmail.com', 'Candelaria', 'El Volcán nº 2', '38295', 'S/C de Tenerife', '11/04/1996'),
(12, 9, 'Peter Jam Jim', '651423000', 'peter@gmail.com', 'Guía de Isora', 'El Hostal nº 3', '38963', 'S/C de Tenerife', '11/01/1980'),
(13, 6, 'Oleger ´Díaz Alonso', '625456123', 'oleger@gmail.com', 'Teror', 'El Fresón nº 1', '38269', 'Gran Canaria', '12/06/1976'),
(14, 11, 'Rosa María Pérez Rojas', '654963369', 'rosa@gmail.com', 'La Laguna', 'La Laja nº 7', '38293', 'S/C de Tenerife', '12/04/1998'),
(15, 13, 'Elías Santana Santana', '654789320', 'eliassantana@gmail.com', 'Telde', 'El Mesén nº 8', '38295', 'Gran Canaria', '12/03/1992');

--
-- Disparadores `cliente`
--
DROP TRIGGER IF EXISTS `trigger_cliente_historico`;
DELIMITER $$
CREATE TRIGGER `trigger_cliente_historico` AFTER INSERT ON `cliente` FOR EACH ROW BEGIN 
 INSERT INTO cliente_historico(Código_Cliente, Id_Comercial, Nombre_Completo,Teléfono,Email,Municipio,Dirección,CódigoPostal,Provincia,Fecha_Nacimiento)
   VALUES (NEW.Código_Cliente, NEW.Id_Comercial, NEW.Nombre_Completo,NEW.Teléfono,NEW.Email,NEW.Municipio,NEW.Dirección,NEW.CódigoPostal,NEW.Provincia,NEW.Fecha_Nacimiento);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `clientes_grancanaria`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `clientes_grancanaria`;
CREATE TABLE IF NOT EXISTS `clientes_grancanaria` (
`Código_Cliente` int(11)
,`Id_Comercial` int(11)
,`Nombre_Completo` varchar(50)
,`Teléfono` varchar(15)
,`Email` varchar(30)
,`Municipio` varchar(30)
,`Dirección` varchar(50)
,`CódigoPostal` varchar(10)
,`Provincia` varchar(30)
,`Fecha_Nacimiento` varchar(10)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `clientes_tenerife`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `clientes_tenerife`;
CREATE TABLE IF NOT EXISTS `clientes_tenerife` (
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `codigos_facturas`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `codigos_facturas`;
CREATE TABLE IF NOT EXISTS `codigos_facturas` (
`Código_Factura` int(11)
,`Código_Cliente` int(11)
,`Número_Pago` int(11)
,`Fecha` datetime
,`Descuento` varchar(10)
,`Igic` varchar(10)
,`Total` int(11)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comercial_soporte`
--

DROP TABLE IF EXISTS `comercial_soporte`;
CREATE TABLE IF NOT EXISTS `comercial_soporte` (
  `Id_Comercial` int(11) NOT NULL,
  `Nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Responsable_Área` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Téléfono_Soporte` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Comercial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `comercial_soporte`
--

INSERT INTO `comercial_soporte` (`Id_Comercial`, `Nombre`, `Apellidos`, `Responsable_Área`, `Téléfono_Soporte`) VALUES
(1, 'Sergio ', 'Rojas Rojas', 'Hardware', '922653287'),
(2, 'Marta', 'López López', 'Sistemas', '654789123'),
(3, 'Luis', 'Dávila Dávila', 'Mantenimiento Pc', '654320123'),
(4, 'Sonia ', 'Pérez Perez', 'Técnico soporte', '654789100'),
(5, 'Pedro', 'Gónzalez Gonzalez', 'Jefe Departamento Hardware', '654741000'),
(6, 'Lorena', 'Rodriguez Rodriguez', 'Software Depelover', '654123032'),
(7, 'Florentín ', 'Guzmán Guzmán', 'Programación', '654121123'),
(8, 'Paco', 'Gónzalez Pérez', 'Instalación Software', '654789111'),
(9, 'Celia ', 'Pérez Pérez', 'Base Datos', '65471023'),
(10, 'Esperanza', 'Rojas Rojas', 'Jefa Departamento Software', '654777888'),
(11, 'Ramón', 'Gónzalez Gónzalez', 'Desarrollo Web', '654123321'),
(12, 'Jaime ', 'Morales Morales', 'Programación Web', '654789100'),
(13, 'César', 'Luengo Luengo', 'Mantemiento Web', '654111100'),
(14, 'Teresa', 'Rivero Rivero', 'Jefa Departamento web', '654789000'),
(15, 'Eduardo', 'Rojas Pérez', 'Servicios', '654333222');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_ventas`
--

DROP TABLE IF EXISTS `detalles_ventas`;
CREATE TABLE IF NOT EXISTS `detalles_ventas` (
  `Código_Detalle` int(11) NOT NULL,
  `Id_Venta` int(11) NOT NULL,
  `Código_Producto` int(11) NOT NULL,
  `Código_Factura` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`Código_Detalle`),
  KEY `Id_Venta` (`Id_Venta`),
  KEY `Código_Producto` (`Código_Producto`),
  KEY `Código_Factura` (`Código_Factura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `detalles_ventas`
--

INSERT INTO `detalles_ventas` (`Código_Detalle`, `Id_Venta`, `Código_Producto`, `Código_Factura`, `Cantidad`, `Total`) VALUES
(1, 1, 102, 1, 1, 100),
(2, 2, 200, 2, 1, 200),
(3, 3, 103, 3, 1, 1000),
(4, 4, 105, 4, 1, 600),
(5, 5, 100, 5, 1, 600),
(6, 6, 106, 6, 1, 750),
(7, 7, 200, 7, 1, 200),
(8, 8, 302, 8, 1, 1500),
(9, 9, 104, 9, 1, 500),
(10, 10, 400, 10, 1, 1800),
(11, 11, 103, 11, 1, 2160),
(12, 12, 200, 12, 1, 1800),
(13, 13, 106, 13, 1, 1500),
(14, 14, 302, 14, 1, 2700),
(15, 15, 103, 15, 1, 1200);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

DROP TABLE IF EXISTS `factura`;
CREATE TABLE IF NOT EXISTS `factura` (
  `Código_Factura` int(11) NOT NULL,
  `Código_Cliente` int(11) NOT NULL,
  `Número_Pago` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Descuento` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Igic` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`Código_Factura`),
  KEY `Código_Cliente` (`Código_Cliente`),
  KEY `Número_Pago` (`Número_Pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`Código_Factura`, `Código_Cliente`, `Número_Pago`, `Fecha`, `Descuento`, `Igic`, `Total`) VALUES
(1, 1, 1, '2020-10-19 13:29:48', '0', '0', 1000),
(2, 8, 2, '2020-10-19 17:31:01', '0', '0', 200),
(3, 3, 3, '2020-10-19 17:31:49', '0', '0', 1000),
(4, 11, 4, '2020-10-19 17:31:49', '0', '0', 600),
(5, 8, 5, '2020-10-19 17:33:14', '0', '0', 600),
(6, 10, 6, '2020-10-19 17:33:14', '0', '0', 750),
(7, 10, 7, '2020-10-19 17:34:24', '0', '0', 200),
(8, 1, 8, '2020-10-19 17:34:24', '0', '0', 1500),
(9, 12, 9, '2020-10-19 17:35:39', '0', '0', 500),
(10, 14, 10, '2020-10-19 17:35:39', '10', '0', 1800),
(11, 12, 11, '2020-10-19 17:40:54', '10', '0', 2160),
(12, 4, 12, '2020-10-19 17:40:54', '10', '0', 1800),
(13, 5, 13, '2020-10-19 17:41:56', '0', '0', 1500),
(14, 7, 14, '2020-10-19 17:41:56', '10', '0', 2700),
(15, 9, 15, '2020-10-19 17:43:04', '0', '0', 1200);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `maxima_total1`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `maxima_total1`;
CREATE TABLE IF NOT EXISTS `maxima_total1` (
`Código_Cliente` int(11)
,`Id_Comercial` int(11)
,`Nombre_Completo` varchar(50)
,`Teléfono` varchar(15)
,`Email` varchar(30)
,`Municipio` varchar(30)
,`Dirección` varchar(50)
,`CódigoPostal` varchar(10)
,`Provincia` varchar(30)
,`Fecha_Nacimiento` varchar(10)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `municipios`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `municipios`;
CREATE TABLE IF NOT EXISTS `municipios` (
`Código_Cliente` int(11)
,`Id_Comercial` int(11)
,`Nombre_Completo` varchar(50)
,`Teléfono` varchar(15)
,`Email` varchar(30)
,`Municipio` varchar(30)
,`Dirección` varchar(50)
,`CódigoPostal` varchar(10)
,`Provincia` varchar(30)
,`Fecha_Nacimiento` varchar(10)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `máximo_total`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `máximo_total`;
CREATE TABLE IF NOT EXISTS `máximo_total` (
`max(Total)` int(11)
,`Código_Cliente` int(11)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

DROP TABLE IF EXISTS `pagos`;
CREATE TABLE IF NOT EXISTS `pagos` (
  `Id_Transacción` int(11) NOT NULL,
  `Código_Cliente` int(11) NOT NULL,
  `Forma_Pago` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `Fecha_Pago` datetime NOT NULL,
  `Total` int(11) NOT NULL,
  `OtrosDetalles` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Transacción`),
  KEY `Código_Cliente` (`Código_Cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`Id_Transacción`, `Código_Cliente`, `Forma_Pago`, `Fecha_Pago`, `Total`, `OtrosDetalles`) VALUES
(1, 1, 'Efectivo', '2020-10-16 16:57:57', 1000, 'Se acerca el cliente a abonarlo en Tienda '),
(2, 8, 'PayPal', '2020-10-17 10:30:31', 200, 'Todo Correcto'),
(3, 3, 'Paypal', '2020-10-18 10:30:31', 1000, 'Ordenador Sobremesa'),
(4, 11, 'Paypal', '2020-10-18 10:35:23', 600, 'Escáner'),
(5, 8, 'Paypal', '2020-10-18 10:35:23', 600, 'Ordenador Pórtatil'),
(6, 10, 'Paypal', '2020-10-17 10:37:58', 750, 'Tarjetas Gráficas Gamer'),
(7, 10, 'Transferencia', '2020-10-19 10:37:58', 200, 'Licencias windows server'),
(8, 1, 'Paypal', '2020-10-18 10:39:27', 1500, 'Diseño Página Web'),
(9, 12, 'Paypal', '2020-10-17 10:39:27', 500, 'Impresoras'),
(10, 14, 'Paypal', '2020-10-18 10:49:36', 1800, '2 Licencias Windows '),
(11, 12, 'Paypal', '2020-10-17 10:49:36', 2160, '2 Ordenadores Lenovo'),
(12, 4, 'Transferencia', '2020-10-19 10:50:38', 1800, 'Programación Portal Web'),
(13, 5, 'Paypal', '2020-10-17 10:50:38', 1500, '2 Tarjetas Gamer'),
(14, 7, 'Paypal', '2020-10-17 10:51:52', 2700, '3 Licencias Azure'),
(15, 9, 'Paypal', '2020-10-18 10:51:52', 1200, '2 Licencias Windows Server');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE IF NOT EXISTS `pedidos` (
  `Código_Pedido` int(11) NOT NULL,
  `Código_Cliente` int(11) NOT NULL,
  `Fecha_Pedido` datetime NOT NULL,
  `Fecha_Esperada` datetime NOT NULL,
  `Fecha_Entrega` datetime NOT NULL,
  `Comentarios` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`Código_Pedido`),
  KEY `Código_Cliente` (`Código_Cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`Código_Pedido`, `Código_Cliente`, `Fecha_Pedido`, `Fecha_Esperada`, `Fecha_Entrega`, `Comentarios`) VALUES
(1, 3, '2020-10-18 10:53:30', '2020-10-19 10:53:30', '2020-10-20 10:53:30', ''),
(2, 12, '2020-10-17 10:53:30', '2020-10-18 10:53:30', '2020-10-19 10:53:30', ''),
(3, 1, '2020-10-17 10:58:11', '2020-10-18 10:58:11', '2020-10-19 10:58:11', 'Ya Abonado'),
(4, 8, '2020-10-17 10:58:11', '2020-10-18 10:58:11', '2020-10-19 10:58:11', 'Ya Abonado'),
(5, 11, '2020-10-17 11:03:35', '2020-10-18 11:03:35', '2020-10-19 11:03:35', 'Ya abonado'),
(6, 8, '2020-10-17 11:04:10', '2020-10-18 11:04:10', '2020-10-19 11:04:10', 'Ya abonado'),
(7, 10, '2020-10-17 11:04:48', '2020-10-18 11:04:48', '2020-10-19 11:04:48', 'Ya abonado'),
(8, 10, '2020-10-17 11:06:22', '2020-10-18 11:06:22', '2020-10-19 11:06:22', 'Ya abonado'),
(9, 1, '2020-10-17 11:07:11', '2020-10-18 11:07:11', '2020-10-19 11:07:11', 'Ya abonado'),
(10, 14, '2020-10-17 11:08:37', '2020-10-18 11:08:37', '2020-10-19 11:08:37', 'Abonado'),
(11, 12, '2020-10-17 11:09:18', '2020-10-18 11:09:18', '2020-10-19 11:09:18', 'Abonado'),
(12, 4, '2020-10-17 11:10:24', '2020-10-18 11:10:24', '2020-10-19 11:10:24', 'Abonado'),
(13, 5, '2020-10-17 11:11:15', '2020-10-18 11:11:15', '2020-10-19 11:11:15', 'Abonado'),
(14, 5, '2020-10-17 11:11:47', '2020-10-18 11:11:47', '2020-10-19 11:11:47', 'Abonado'),
(15, 9, '2020-10-17 11:13:29', '2020-10-18 11:13:29', '2020-10-19 11:13:29', 'Abonado');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `preciomedio_precio_venta`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `preciomedio_precio_venta`;
CREATE TABLE IF NOT EXISTS `preciomedio_precio_venta` (
`avg(Precio_Venta)` decimal(14,4)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `Código_Producto` int(11) NOT NULL,
  `Código_Proveedor` int(11) NOT NULL,
  `Nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Descripción` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Categoria` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Precio_Venta` decimal(10,0) NOT NULL,
  `Precio_Proveedor` decimal(10,0) NOT NULL,
  PRIMARY KEY (`Código_Producto`),
  KEY `Código_Proveedor` (`Código_Proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`Código_Producto`, `Código_Proveedor`, `Nombre`, `Descripción`, `Cantidad`, `Categoria`, `Precio_Venta`, `Precio_Proveedor`) VALUES
(100, 6, 'Ordenadores Portatiles', 'Marca Asus 16 gb de memoria ram.', 20, 'Hardware', '600', '450'),
(101, 10, 'Tarjetas de sonido y Gráficas', 'Últimas marcas de tarjetas de sonidoy gráficas', 20, 'Hardware', '250', '150'),
(102, 6, 'Ordenador Sobremesa Asus', 'Alta gama', 20, 'Hardware', '1000', '800'),
(103, 4, 'Ordenadores Sobremesa Lenovo', 'Ordenadores Lenovo', 20, 'Hardware', '1200', '900'),
(104, 15, 'Impresoras', 'Gama Sobremesa Hp', 15, 'Hardware', '600', '450'),
(105, 10, 'Escaner HP', 'Gama Alta scaner', 12, 'Hardware', '600', '450'),
(106, 15, 'Tarjetas Gráficas Exploit', 'Alta gama pàra gamers', 12, 'Hardware', '700', '500'),
(200, 5, 'Licencias Windows Server 2016', 'Software para grabar en windows 10', 50, 'Software', '200', '100'),
(202, 14, 'Licencias Adobe Premiere', 'Paquete Adobe', 10, 'Software', '900', '700'),
(203, 12, 'Windows 10', 'Licencia Windows 10', 20, 'Software', '1000', '800'),
(204, 13, 'Microsoft Azure', 'Licencias', 10, 'Software', '900', '700'),
(300, 8, 'Dominios ', 'Servicios de Dominios y Alojamiento Web', 2, 'Web', '200', '135'),
(302, 3, 'Wordpress y Alojamientos', 'Diseño  de Páginas', 2, 'Web', '1500', '1100'),
(400, 11, 'Programación web', 'Servicios Webs', 1, 'Servicios', '1800', '1300'),
(401, 2, 'Páginas web', 'Programación de portales web', 1, 'Servicios', '2000', '1500');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
CREATE TABLE IF NOT EXISTS `proveedor` (
  `Código_Proveedor` int(11) NOT NULL,
  `Nombre_Empresa` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Teléfono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `Email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Cif` varchar(9) COLLATE utf8_spanish_ci NOT NULL,
  `Provincia` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`Código_Proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`Código_Proveedor`, `Nombre_Empresa`, `Teléfono`, `Email`, `Cif`, `Provincia`) VALUES
(1, 'Solo Hardware', '922569874', 'hardware@gmail.com', 'B23423445', 'S/C de Tenerife'),
(2, 'Software 2020', '822986453', 'sotware2020@gmail.com', 'B12341148', 'Gran Canaria'),
(3, 'Canarias Web', '922564986', 'webcanarias@gmail.com', 'A12354874', 'S/C de Tenerife'),
(4, 'Sistemas Informáticos Luis', '922568000', 'sistemasluis@gmail.com', 'A35656970', 'S/C de Tenerife'),
(5, 'Canrias Software', '922656484', 'canariassoft@gmail.com', 'B12365400', 'S/C de Tenerife'),
(6, 'Binary Sistemas', '922659874', 'binary@gmail.com', 'B23165477', 'S/C de Tenerife'),
(7, 'Sitemas Informáticos', '922568947', 'sistemas@gmail.com', 'B32165497', 'Gran Canaria'),
(8, 'WebInfopista', '922653200', 'infopista@gmail.com', 'A10213697', 'S/C de Tenerife'),
(9, 'Programacion2000', '922659748', 'programacion@gmail.com', 'B12015978', 'S/C de Tenerife'),
(10, 'Ibersistemas', '922653102', 'ibersistemas@gmail.com', 'B15643269', 'S/C de Tenerife'),
(11, 'webSergio', '922653210', 'webrojas@gmail.com', 'B56123259', 'S/C de Tenerife'),
(12, 'Software César', '922365478', 'cesar@gmail.com', 'B56123212', 'Gran Canaria'),
(13, 'Software VB', '822369874', 'vb@gmail.com', 'B56123203', 'S/C de Tenerife'),
(14, 'Sistemas Programables', '822569841', 'programables@gmail.com', 'B56123236', 'S/C de Tenerife'),
(15, 'Ordenadores Ibercom', '822515487', 'ibercom@gmail.com', 'B56123277', 'Gran Canaria');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `valormasrepetido`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `valormasrepetido`;
CREATE TABLE IF NOT EXISTS `valormasrepetido` (
`Código_Cliente` int(11)
,`count(``Código_Cliente``)` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `valormasrepetido1`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `valormasrepetido1`;
CREATE TABLE IF NOT EXISTS `valormasrepetido1` (
`Código_Cliente` int(11)
,`Total_Pedidos` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE IF NOT EXISTS `ventas` (
  `IdVenta` int(11) NOT NULL,
  `IdComercial` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`IdVenta`),
  KEY `IdComercial` (`IdComercial`),
  KEY `idCliente` (`idCliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`IdVenta`, `IdComercial`, `idCliente`, `Fecha`, `Total`) VALUES
(1, 1, 1, '2020-10-17 13:47:23', 1000),
(2, 8, 8, '2020-10-19 17:51:01', 200),
(3, 2, 3, '2020-10-19 17:53:04', 1000),
(4, 4, 11, '2020-10-19 17:53:04', 600),
(5, 8, 8, '2020-10-19 17:56:07', 600),
(6, 8, 10, '2020-10-19 17:56:07', 750),
(7, 8, 10, '2020-10-19 17:58:12', 200),
(8, 1, 9, '2020-10-19 17:58:12', 1500),
(9, 9, 12, '2020-10-19 18:58:39', 500),
(10, 11, 14, '2020-10-19 19:00:53', 1800),
(11, 9, 12, '2020-10-19 19:01:57', 2160),
(12, 3, 4, '2020-10-19 19:02:34', 1800),
(13, 2, 5, '2020-10-19 19:07:36', 1500),
(14, 12, 7, '2020-10-19 19:08:36', 2700),
(15, 11, 9, '2020-10-19 19:09:12', 1200);

-- --------------------------------------------------------

--
-- Estructura para la vista `clientes_grancanaria`
--
DROP TABLE IF EXISTS `clientes_grancanaria`;

DROP VIEW IF EXISTS `clientes_grancanaria`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clientes_grancanaria`  AS  select `cliente`.`Código_Cliente` AS `Código_Cliente`,`cliente`.`Id_Comercial` AS `Id_Comercial`,`cliente`.`Nombre_Completo` AS `Nombre_Completo`,`cliente`.`Teléfono` AS `Teléfono`,`cliente`.`Email` AS `Email`,`cliente`.`Municipio` AS `Municipio`,`cliente`.`Dirección` AS `Dirección`,`cliente`.`CódigoPostal` AS `CódigoPostal`,`cliente`.`Provincia` AS `Provincia`,`cliente`.`Fecha_Nacimiento` AS `Fecha_Nacimiento` from `cliente` where `cliente`.`Provincia` like 'Gran Canaria' order by `cliente`.`Nombre_Completo` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `clientes_tenerife`
--
DROP TABLE IF EXISTS `clientes_tenerife`;

DROP VIEW IF EXISTS `clientes_tenerife`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clientes_tenerife`  AS  select `cliente`.`Código_Cliente` AS `Código_Cliente`,`cliente`.`Id_Comercial` AS `Id_Comercial`,`cliente`.`Nombre_Completo` AS `Nombre_Completo`,`cliente`.`Teléfono` AS `Teléfono`,`cliente`.`Email` AS `Email`,`cliente`.`Municipio` AS `Municipio`,`cliente`.`Dirección` AS `Dirección`,`cliente`.`CódigoPostal` AS `CódigoPostal`,`cliente`.`Provincia` AS `Provincia`,`cliente`.`Fecha_Nacimiento` AS `Fecha_Nacimiento` from `cliente` where `cliente`.`Provincia` like 'S/C de Tenerife' order by `cliente`.`Nombre_Completo` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `codigos_facturas`
--
DROP TABLE IF EXISTS `codigos_facturas`;

DROP VIEW IF EXISTS `codigos_facturas`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `codigos_facturas`  AS  select `factura`.`Código_Factura` AS `Código_Factura`,`factura`.`Código_Cliente` AS `Código_Cliente`,`factura`.`Número_Pago` AS `Número_Pago`,`factura`.`Fecha` AS `Fecha`,`factura`.`Descuento` AS `Descuento`,`factura`.`Igic` AS `Igic`,`factura`.`Total` AS `Total` from `factura` where `factura`.`Código_Factura` in ('1','11') ;

-- --------------------------------------------------------

--
-- Estructura para la vista `maxima_total1`
--
DROP TABLE IF EXISTS `maxima_total1`;

DROP VIEW IF EXISTS `maxima_total1`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `maxima_total1`  AS  select `cliente`.`Código_Cliente` AS `Código_Cliente`,`cliente`.`Id_Comercial` AS `Id_Comercial`,`cliente`.`Nombre_Completo` AS `Nombre_Completo`,`cliente`.`Teléfono` AS `Teléfono`,`cliente`.`Email` AS `Email`,`cliente`.`Municipio` AS `Municipio`,`cliente`.`Dirección` AS `Dirección`,`cliente`.`CódigoPostal` AS `CódigoPostal`,`cliente`.`Provincia` AS `Provincia`,`cliente`.`Fecha_Nacimiento` AS `Fecha_Nacimiento` from `cliente` where `cliente`.`Código_Cliente` = 14 and (select max(`factura`.`Total`) from `factura`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `municipios`
--
DROP TABLE IF EXISTS `municipios`;

DROP VIEW IF EXISTS `municipios`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `municipios`  AS  select `cliente`.`Código_Cliente` AS `Código_Cliente`,`cliente`.`Id_Comercial` AS `Id_Comercial`,`cliente`.`Nombre_Completo` AS `Nombre_Completo`,`cliente`.`Teléfono` AS `Teléfono`,`cliente`.`Email` AS `Email`,`cliente`.`Municipio` AS `Municipio`,`cliente`.`Dirección` AS `Dirección`,`cliente`.`CódigoPostal` AS `CódigoPostal`,`cliente`.`Provincia` AS `Provincia`,`cliente`.`Fecha_Nacimiento` AS `Fecha_Nacimiento` from `cliente` where `cliente`.`Municipio` in ('La Laguna','S/C de Tenerife','Tegueste') ;

-- --------------------------------------------------------

--
-- Estructura para la vista `máximo_total`
--
DROP TABLE IF EXISTS `máximo_total`;

DROP VIEW IF EXISTS `máximo_total`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `máximo_total`  AS  select max(`factura`.`Total`) AS `max(Total)`,`factura`.`Código_Cliente` AS `Código_Cliente` from `factura` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `preciomedio_precio_venta`
--
DROP TABLE IF EXISTS `preciomedio_precio_venta`;

DROP VIEW IF EXISTS `preciomedio_precio_venta`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `preciomedio_precio_venta`  AS  select avg(`productos`.`Precio_Venta`) AS `avg(Precio_Venta)` from `productos` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `valormasrepetido`
--
DROP TABLE IF EXISTS `valormasrepetido`;

DROP VIEW IF EXISTS `valormasrepetido`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `valormasrepetido`  AS  select `pedidos`.`Código_Cliente` AS `Código_Cliente`,count(`pedidos`.`Código_Cliente`) AS `count(``Código_Cliente``)` from `pedidos` group by `pedidos`.`Código_Cliente` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `valormasrepetido1`
--
DROP TABLE IF EXISTS `valormasrepetido1`;

DROP VIEW IF EXISTS `valormasrepetido1`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `valormasrepetido1`  AS  select `pedidos`.`Código_Cliente` AS `Código_Cliente`,count(0) AS `Total_Pedidos` from `pedidos` group by `pedidos`.`Código_Cliente` ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`Id_Comercial`) REFERENCES `comercial_soporte` (`Id_Comercial`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalles_ventas`
--
ALTER TABLE `detalles_ventas`
  ADD CONSTRAINT `detalles_ventas_ibfk_1` FOREIGN KEY (`Id_Venta`) REFERENCES `ventas` (`IdVenta`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalles_ventas_ibfk_2` FOREIGN KEY (`Código_Factura`) REFERENCES `factura` (`Código_Factura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalles_ventas_ibfk_3` FOREIGN KEY (`Código_Producto`) REFERENCES `productos` (`Código_Producto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`Código_Cliente`) REFERENCES `cliente` (`Código_Cliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `factura_ibfk_2` FOREIGN KEY (`Número_Pago`) REFERENCES `pagos` (`Id_Transacción`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`Código_Cliente`) REFERENCES `cliente` (`Código_Cliente`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`Código_Cliente`) REFERENCES `cliente` (`Código_Cliente`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`Código_Proveedor`) REFERENCES `proveedor` (`Código_Proveedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`IdComercial`) REFERENCES `comercial_soporte` (`Id_Comercial`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`Código_Cliente`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
